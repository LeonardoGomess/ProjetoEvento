package fiap.com.br.projetoEvento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Leonardo94183ApplicationTests {

	@Test
	void contextLoads() {
	}

}
