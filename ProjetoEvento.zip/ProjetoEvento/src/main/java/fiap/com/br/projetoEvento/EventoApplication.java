package fiap.com.br.projetoEvento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventoApplication {

	public static void main(String[] args) {

		SpringApplication.run(EventoApplication.class, args);
	}

}
