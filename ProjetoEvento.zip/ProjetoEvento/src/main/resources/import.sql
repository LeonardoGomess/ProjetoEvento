INSERT INTO tb_cidades(nome,estado) VALUES('Nova York','Nova York');
INSERT INTO tb_cidades(nome,estado) VALUES('Los Angeles', 'Califórnia');
INSERT INTO tb_cidades(nome,estado) VALUES('Chicago', 'Illinois');
INSERT INTO tb_cidades(nome,estado) VALUES('São Paulo','São Paulo');
INSERT INTO tb_cidades(nome,estado) VALUES('Miami', 'Flórida');


INSERT INTO tb_eventos(nome, data, url,cidade_id) VALUES ('Conferência de Tecnologia 2024', '2024-05-15', 'http://exemplo.com/conferencia-tecnologia-2024',1);
INSERT INTO tb_eventos(nome, data, url,cidade_id) VALUES ('Festival de Arte Moderna', '2024-06-20', 'http://exemplo.com/festival-arte-moderna',2);
INSERT INTO tb_eventos(nome, data, url,cidade_id) VALUES ('Exposição de Fotografia Contemporânea', '2024-07-10', 'http://exemplo.com/exposicao-fotografia-contemporanea',3);
INSERT INTO tb_eventos(nome, data, url,cidade_id) VALUES ('Seminário de Marketing Digital', '2024-08-05', 'http://exemplo.com/seminario-marketing-digital',4);
INSERT INTO tb_eventos(nome, data, url,cidade_id) VALUES ('Concerto ao Ar Livre', '2024-09-15', 'http://exemplo.com/concerto-ar-livre',5);
